package br.com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SouzacarApplication {

	public static void main(String[] args) {
		SpringApplication.run(SouzacarApplication.class, args);
	}
}
